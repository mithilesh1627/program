import cv2
import time
import numpy as np
import module_hand_tracking as htm
import math
import pycaw
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

#########################
Wcam , Hcam =640,480
#########################

cap =cv2.VideoCapture(0)
cap.set(3,Wcam)
cap.set(4,Hcam)
ptime = 0

detector = htm.HandDetector(min_detection_confidence=0.7,max_num_hands=1)


#pycaw
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(
    IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))
#volume.GetMute()
#volume.GetMasterVolumeLevel()
volRange = volume.GetVolumeRange()
minVol = volRange[0]
maxVol = volRange[1]
vol= 0
vol_bar = 400
vol_per = 0
area = 0
color_Vol = (255,0,0)
while True:
    success ,img = cap.read()
    #find hand
    img = detector.FindHands(img)
    lm_list,bbox = detector.FindPosition(img,draw=True)
    if len(lm_list)!=0:
        #filter based on size
        area = (bbox[2]-bbox[0])*(bbox[3]-bbox[1])//100

        if  250 < area < 1000:
            #find distance of index and thumb
            length, img , lineInfo  = detector.FindDistance(4,8,img)
            # print(length)


            # convert Volume
                # HandRange= 58 - 300
                # VolumeRange =-65 - 0
            vol_bar = np.interp(length, [30, 200], [400, 150])
            vol_per = np.interp(length, [30, 200], [0, 100])
            # reduce resolution to make it smoother
            smoothness = 10
            vol_per = smoothness *round(vol_per/smoothness)
            # check finger up
            finger  =detector.FingerUp()
            print(finger)
            # if pinky is down set volume
            if not finger[4]:
                volume.SetMasterVolumeLevelScalar(vol_per/100, None)
                cv2.circle(img, (lineInfo[4], lineInfo[5]), 10, (0,255, 0), cv2.FILLED)
                color_Vol = (0,255,0)
                # time.sleep(0.25)
            else:
                color_Vol =(255,0,0)
    # drawing
    cv2.rectangle(img,(50,150),(85,400),(255,0,0),3)
    cv2.rectangle(img,(50,int(vol_bar)),(85,400),(255,0,0),cv2.FILLED)
    cv2.putText(img, f'{int(vol_per)} %', (40, 450), cv2.FONT_HERSHEY_DUPLEX,
                1, (255, 0, 0), 2)
    current_vol = int(volume.GetMasterVolumeLevelScalar()*100)
    cv2.putText(img, f"Vol Set: {int(current_vol)}", (400, 50), cv2.FONT_HERSHEY_DUPLEX,
                1, color_Vol, 2)

    # frame rate
    ctime=time.time()
    fps = 1/(ctime - ptime)
    ptime = ctime
    cv2.putText(img,str(int(fps)),(47,77),cv2.FONT_HERSHEY_DUPLEX,
                1,(255,0,0),2)
    cv2.imshow("Image",img)
    cv2.waitKey(1)