import numpy as np
import cv2
from pyzbar.pyzbar import decode

# img = cv2.imread("res/mithilesh_qr.png")
cap = cv2.VideoCapture(0)
cap.set(3,700)
cap.set(4,700)


with open('my_data_file') as f:
    my_data_list = f.read().splitlines()

while True:

    flag , img =cap.read()
    for barcode in decode(img):
        my_data = barcode.data.decode('utf-8')
        print(my_data)
        if my_data in my_data_list:
            my_output = "Authorized"
            my_colour = (0,255,0)
        else:
            my_output = "Unauthorized"
            my_colour = (0,0 ,255)
        pts = np.array([barcode.polygon],np.int32)
        pts = pts.reshape((-1,1,2))
        cv2.polylines(img,[pts],True,(255,0,255),5)
        pts2 =barcode.rect
        cv2.putText(img,my_output,(pts2[0],pts2[1]),
                    cv2.FONT_HERSHEY_DUPLEX,0.9,my_colour,2)
    cv2.imshow("window",img)
    cv2.waitKey(1)