import requests
import json
import phonenumbers
from phonenumbers import carrier
from phonenumbers import geocoder
import smtplib
import random
import sys
import pyttsx3
import os
import pyaudio 
import wikipedia
import datetime
import webbrowser
import speech_recognition as sr
r1=sr.Recognizer()
engine=pyttsx3.init('sapi5')
voices=engine.getProperty('voices')
#print(voices[1].id)
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate', 170)
engine.setProperty('volume',1)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
def wiseme():
    hours=int(datetime.datetime.now().hour)
    if hours>=0 and hours<12:
        speak("good morning  mithilesh ! , have a nice day sir")
    elif hours>=12 and hours<18:
        speak("good afternoon mithilesh !")
    elif hours >=18 and hours<22:
        speak("good evening mithilesh !")
    else:
        speak("good night mithilesh have a sweet dream sir ")
    speak("i am  jarvis mithilesh , please tell me how can i help you ")
def takecommand():
    #"this function take input from microphone of user device and return string output"
    r=sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold=1
        r.enrgy_threshold=800
        audio=r.listen(source)
    try:
        print("Recognizing...")
        query = r.recognize_google(audio , language='en-in')#recongize_bing()
        #recongnize_google()recongize_houndify()recongize_ibm() recongize_wit() recongize_sphins()
        print("you said " , query)
    except Exception as e:
        #it gives all exception during runtime
        #print(e)# it will print error
        print("say that again please...")
        return "None"
    return query
def sendEmail(to, content):
    password='password'
    server=smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.login('mithileshchaurasiya1627@gmail.com',password)
    server.sendmail('mithileshchaurasiya1627@gmail.com',to,content)
    server.close()
def sms():
    speak("sir wait for connection to send message")
    print("connected")
    URL = 'https://www.sms4india.com/api/v1/sendCampaign'
    # get request
    def sendPostRequest(reqUrl, apiKey, secretKey, useType, phoneNo, senderId, textMessage):
      req_params = {
      'apikey':apiKey,
      'secret':secretKey,
      'usetype':useType,
      'phone': phoneNo,
      'message':textMessage,
      'senderid':senderId
      }
      return requests.post(reqUrl, req_params)
    # get response
    speak("connected")
    speak("whom i send the sms sir !, please enter reciver phone number")
    number=int(input("enter the reciver phone number "))
    speak(" sir what should message contain")
    content=takecommand()
    response = sendPostRequest(URL, 'Y3V07E3EN2FTP0QMMVKEUL9FYU4ZLJUQ', '68NMHQ5D1KRBWQ0T', 'stage', number, 'mithilesh', content)
    """
      Note:-
        you must provide apikey, secretkey, usetype, mobile, senderid and message values
        and then requst to api
    """
    # print response if you want
    bal=response.text
    print(bal)
    speak(bal)
def alarm():
    speak(" sir enter  the hour of alarm ")
    alarmhour=int(input("enter hours of alarm"))
    speak("now enter   the minute of alarm ")
    alarmmin=int(input("enter the minute of alarm"))
    speak("sir ,  enter am or pm  of  alarm ")
    am_pm=str(input("am or pm :"))
    r="what should be reminder of alarm"
    print(r)
    speak(r)
    reminder=takecommand()
    speak("reminder  and alarm is set")
    am_pm.lower()
    if(am_pm=="pm"):
        alarmhour=int(alarmhour) + 12
    while(1==1):
        if (alarmhour==datetime.datetime.now().hour and
            alarmmin==datetime.datetime.now().minute):
            alarm_sound="wake up  sir  \n wake up sir\nwake up  sir "
            speak(alarm_sound)
            music_dir='C:\\Users\\mithilesh\\Music'
            q=random.randrange(1,434)
            songs=os.listdir(music_dir)
            os.startfile(os.path.join(music_dir,songs[q]))
            #continue # for not play a music only alarm_sound
            break# for both music and alarm_sound
def check_phone_number():
    speak("enter the phone number sir")
    num=input("enter phone number with ISD code")
    print("entered number is " + num)
    #for check the carrier of number
    ser_num=phonenumbers.parse(num ,"RO")
    car=carrier.name_for_number(ser_num ,"en")
    car_info="the carrier of phone number is " + car
    print(car_info)
    speak(car_info)
    #for checking the country of number 
    ch_number=phonenumbers.parse(num ,"CH")
    coun=geocoder.description_for_number(ch_number,"en")
    count_info=("the number from " + coun )
    print(count_info)
    speak(count_info)
def google():
    url_google='https://www.google.com/search?q='
    search_on_google="what i should search  on google"
    print(search_on_google)
    speak(search_on_google)
    get_google=takecommand()
    webbrowser.get().open(url_google+get_google)
def youtube():
    url_youtube='https://www.youtube.com/results?search_query='
    search_on_youtube="what i should search  on youtube"
    print(search_on_youtube)
    speak(search_on_youtube)
    get_youtube=takecommand()
    webbrowser.get().open(url_youtube+get_youtube)
def shutdown():
    speak("yes sir saving states of all program")
    confirm= " state of all program is saved , sir ! surely  you want to shutdown the computer"
    speak(confirm)
    confirm_for_shutdown=takecommand()
    if confirm_for_shutdown=='yes':
        os.system("shutdown /s /t 1")
    else:
        exit()
def restart():
    speak("yes sir! saving states of all program")
    confirmr= " state of all program is saved , sir ! surely youwant to restart  the computer"
    speak(confirmr)
    confirm_for_restart=takecommand()
    if confirm_for_restart=='yes':
        os.system("shutdown /r /t 1")
    else:
        exit()
if __name__=="__main__":
    #speak("mithilesh is good boy")
    wiseme()
    while True:#for infinte time 
    #if 1:# for 1 time only
        query = takecommand().lower()
        #logic task based on query
        if 'wikipedia' in query:
            speak("searching on wikipedia")
            query=query.replace("wikipedia","")
            results=wikipedia.summary(query, sentences=6)
            speak("according to wikipedia")
            print(results)
            engine.setProperty('rate', 200)
            speak(results)
        elif 'youtube' in query:
            youtube()
        elif 'open google' in query:
            google()
        elif 'open facebook' in query:
            webbrowser.open("facebook.com")
        elif 'open instagram' in query:
            webbrowser.open("instagram.com")
        elif 'sms' in query:
            sms()
        elif 'check number ' in query or 'number' in query: 
            check_phone_number()
        elif 'time' in query:
            strTime=datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"Sir, the time is {strTime}")
        elif 'shutdown the computer'in query:
            shutdown()
        elif 'restart the computer'in query:
            restart() 
        elif ' music'  in query:
            music_dir='C:\\Users\\mithilesh\\Music'
            music=random.randrange(1,434)
            songs=os.listdir(music_dir)
            os.startfile(os.path.join(music_dir,songs[music]))
        elif 'alarm' in query:
            speak("wait setting the alarm")
            alarm()            
        elif 'open file' in query:
            os.startfile("‪D:\\jarvis.py")
        elif 'what can you do' in query:
            do="sir i can open  and search anything on youtube , google ,facebook,send the email , play some music,i can search anything in wikipedia and  for you i set the  alarm sir "
            print(do)
            speak(do)

        elif 'down ' in query:
            speak("ok sir wait..\n shutting down the jarvis ")
            exit(1)
            sys.exit(0)
            raise SystemExit
        elif 'send email' in query:
            try:
                speak("what should i send in content sir ")
                content= takecommand()
                speak("to whom i sent email") 
                to=str(input("enter the email id of receiver" ))
                sendEmail(to,content)
                sent="email has  successfully  send "
                speak(sent)
            except Exception as e:
                print(e)
                speak("sorry my sir i am not able to send email rihgt now")
    
                
            
            
