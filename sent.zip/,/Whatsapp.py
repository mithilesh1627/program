import sys
from selenium import webdriver
import time

def user_char_function(n):
    time.sleep(9)
    # user_profile = browser.find_element_by_xpath(
    #     '//*[@id="pane-side"]/div[1]/div/div/div[2]/div/div/div[2]/div[1]/div[1]')
    # user_profile.click()
    message_box = browser.find_element_by_xpath(
        '//*[@id="main"]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[2]')
    for i in range(n):

        message_box.send_keys(f'Hi Sandhya! ... this is Whatsapp bot from Mithilesh '
                              f'Message number{i}')
        send_key = browser.find_element_by_xpath('//*[@id="main"]/footer/div[1]/div/span[2]/div/div[2]/div[2]')
        send_key.click()
        # time.sleep(1)

if __name__ =='__main__':
    my_option = webdriver.ChromeOptions()
    # print('opening')
    browser = webdriver.Chrome('chromedriver.exe')
    browser.get('https://web.whatsapp.com/')
    # print ('opened')
    time.sleep(20)

    search_bar = browser.find_element_by_xpath('//*[@id="side"]/div[1]/div/label/div/div[2]')
    search_bar.click()
    search_bar.send_keys('Ghar')
    time.sleep(20)
    search_bar_close = browser.find_element_by_xpath('//*[@id="side"]/div[1]/div/span/button/span')
    user_char_function(2000)
    search_bar_close.click()
    print("message send")