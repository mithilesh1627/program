import cv2
import time
import numpy as np
import module_hand_tracking as htm
import math
import pycaw
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

#########################
Wcam , Hcam =640,480
#########################

cap =cv2.VideoCapture(0)
cap.set(3,Wcam)
cap.set(4,Hcam)
ptime = 0

detector = htm.HandDetector(min_detection_confidence=0.7)


#pycaw
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(
    IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))
#volume.GetMute()
#volume.GetMasterVolumeLevel()
volRange = volume.GetVolumeRange()
minVol = volRange[0]
maxVol = volRange[1]
vol= 0
vol_bar = 400
vol_per = 0
while True:
    success ,img = cap.read()
    #find hand
    img = detector.FindHands(img)
    lm_list = detector.FindPosition(img,draw=False)
    if len(lm_list)!=0:
        #filter based on size
        #find distance of index and thumb
        # convert Volume
        # reduce resolution to make it smoother
        # check finger up
        # if pinky is down set volume
        # drawing
        #frame rate
        #print(lm_list[4],lm_list[8])
        x1 ,y1 = lm_list[4][1], lm_list[4][2]
        x2 ,y2 = lm_list[8][1],lm_list[8][2]
        cx ,cy = (x1+x2)//2 ,(y1+y2)//2


        cv2.circle(img,(x1,y1),10,(255,0,0),cv2.FILLED)
        cv2.circle(img,(x2,y2),10,(255,0,0),cv2.FILLED)
        cv2.line(img,(x1,y1),(x2,y2),(255,0,0),3,cv2.LINE_AA)
        cv2.circle(img,(cx,cy),10,(255,0,0),cv2.FILLED)

        length = math.hypot(x2-x1,y2-y1)
        #print(length)

        #HandRange= 58 - 300
        #VolumeRange =-65 - 0

        vol = np.interp(length,[30,220],[minVol,maxVol])
        vol_bar= np.interp(length,[30,220],[400,150])
        vol_per= np.interp(length,[30,220],[0,100])

        print(int(length),vol)
        volume.SetMasterVolumeLevel(vol, None)

        if length < 50:
            cv2.circle(img, (cx, cy), 10, (0,255, 0), cv2.FILLED)

    cv2.rectangle(img,(50,150),(85,400),(255,0,0),3)
    cv2.rectangle(img,(50,int(vol_bar)),(85,400),(255,0,0),cv2.FILLED)
    cv2.putText(img, f'{int(vol_per)} %', (40, 450), cv2.FONT_HERSHEY_DUPLEX,
                1, (255, 0, 0), 2)

    ctime=time.time()
    fps = 1/(ctime - ptime)
    ptime = ctime
    cv2.putText(img,str(int(fps)),(47,77),cv2.FONT_HERSHEY_DUPLEX,
                1,(255,0,0),2)
    cv2.imshow("Image",img)
    cv2.waitKey(1)