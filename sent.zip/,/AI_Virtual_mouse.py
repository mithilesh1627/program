import cv2
import numpy as np
import module_hand_tracking as mht
import time
import autopy
#################
wcam , hcam  = 640,480
frameR = 100 # Frame Reduction
smoothing = 7
#################

pTime = 0
pLocX , pLocY =0 , 0
cLocX , cLocY = 0 , 0

cap = cv2.VideoCapture(0)
cap.set(3,wcam)
cap.set(4,hcam)
detector = mht.HandDetector(max_num_hands=1)
wscreen ,hscreen = autopy.screen.size()
# print(wscreen,hscreen)
while True:
    #1) to find hand landmarks
    sucess , img = cap.read()
    img = detector.FindHands(img)
    lmlist , bbox = detector.FindPosition(img)
    #print(lmlist)

    # 2)get the tip of index and middle finger
    if len(lmlist)!= 0:
        x1 , y1 = lmlist[8][1:]
        x2 , y2 =lmlist[12][1:]
        #print(x1,y1 ,x2,y2)

        #3)check which finger are up
        fingers = detector.FingerUp()
        #print(fingers)
        cv2.rectangle(img, (frameR, frameR),(wcam - frameR , hcam - frameR),(255, 0, 255), 2)
        #4)only index finger : moving mode
        if fingers[1] == 1 and fingers[2] == 0:
            #5)Convert coordinate
            x3 = np.interp(x1,(frameR,wcam-frameR),(0,wscreen))
            y3 = np.interp(y1,(frameR,hcam-frameR),(0,hscreen))
            #6)smoothen value
            cLocX = pLocX + (x3 - pLocX) / smoothing
            cLocY = pLocY + (y3 - pLocY) / smoothing

            #7)Move mouse
            autopy.mouse.move(wscreen-cLocX , cLocY)
            cv2.circle(img,(x1,y1),15,(255,0,255),cv2.FILLED)
            pLocX ,pLocY = cLocX , cLocY

        # 8)both index and middle finger are up: click mode
        if fingers[1] == 1 and fingers[2] == 1:
            # 9) find distance between finger

            length,img, lineinfo = detector.FindDistance(8,12,img)
            print(length)
            # 10) click mouse if distance short
            if length < 32 :
                cv2.circle(img,(lineinfo[4],lineinfo[5]),15,
                           (0,255,0),cv2.FILLED)
                autopy.mouse.click()




    #11) frame rate
    # cTime = time.time()
    # print("cTime",cTime)
    # fps = 1/(cTime - pTime)
    # pTime = cTime
    # print("Ptime",pTime)

    #12) display
    # cv2.putText(img,str(int(fps)),(20,50),cv2.FONT_HERSHEY_PLAIN,3
    #             ,(255,0,0),3)
    cv2.imshow("img", img)
    cv2.waitKey(1)

