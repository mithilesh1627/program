import cv2
import os
import module_hand_tracking as mht
import pyttsx3
wcam ,hcam =640 , 480


cap = cv2.VideoCapture(0)
cap.set(3,wcam)
cap.set(4, hcam)


folder_path= "image for finger counting"
my_list = os.listdir(folder_path)
print(my_list)
overlay_list = []


detector = mht.HandDetector(min_detection_confidence=0.75)
tip_id =[4,8,12,16,20]

engine=pyttsx3.init('sapi5')
voices=engine.getProperty('voices')
#print(voices[1].id)
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate', 170)
engine.setProperty('volume',1)


for imagepath in my_list:
    image = cv2.imread(f"{folder_path}/{imagepath}")
    # print(f"{folder_path}/{imagepath}")
    overlay_list.append(image)
print(len(overlay_list))


while True:
    success , img = cap.read()
    img = detector.FindHands(img)
    lmlist =detector.FindPosition(img,draw=False)
    # print(lmlist)

    if len(lmlist)!=0:
        finger = []
        # Thumb
        if lmlist[tip_id[0]][1] > lmlist[tip_id[0] - 1][1]:
            finger.append(1)
        else:
            finger.append(0)

        # finger
        for id in range(1,5):
            if lmlist[tip_id[id]][2] < lmlist[tip_id[id]-2][2]:
                finger.append(1)
            else:
                finger.append(0)
        #print(finger)
        total_fingers = finger.count(1)
        print(total_fingers)
        h, w, c = overlay_list[total_fingers].shape
        img[0:h,0:w] = overlay_list[total_fingers]

        # cv2.rectangle(img,(20,255),(170,425),(0,255,0),cv2.FILLED)
        #cv2.putText(img,str(total_fingers),(100,100),cv2.FONT_HERSHEY_DUPLEX
         #           ,9,(255,0,0),25)
        engine.say(total_fingers)
        engine.runAndWait()


    cv2.imshow("Image" , img)
    cv2.waitKey(1)
