import cv2
import mediapipe as mp
import time
import numpy as np
import os
import module_hand_tracking as mht
###############
brushThickness = 15
eraserThickness = 100
################
folderpath = "header_img"
my_list = os.listdir(folderpath)
# print(my_list)
overlay_list = []

for img_path in my_list:
    img = cv2.imread(f"{folderpath}//{img_path}")
    img = cv2.resize(img,(1280,147),fx=0.1,fy=0.1)
    overlay_list.append(img)
# print(len(overlay_list))
header = overlay_list[0]
drawcolour = (255,0,255)

cap = cv2.VideoCapture(0)
cap.set(3,1200)
cap.set(4,720)

detector = mht.HandDetector(min_detection_confidence=0.85,max_num_hands=1)
xp , yp = 0 , 0

imgCanvas = np.zeros((720,1280,3),np.uint8)
while True:
    # step:
    # 1) import image
    sucess ,img = cap.read()
    img = cv2.flip(img,1)
    # 2) Find Hand Landmarks
    img = detector.FindHands(img)
    lmlist = detector.FindPosition(img,draw=False)

    if len(lmlist)!= 0:
        # print(lmlist)
        #tip of index figure and middle finger
        x1,y1 = lmlist[8][1:]
        x2,y2 = lmlist[12][1:]

        # 3) check which finger up
        fingers=detector.FingerUp()
        # print(fingers)


        # 4) IF selection mode - Two finger are up
        if fingers[1] and fingers[2]:
            xp, yp = 0 , 0
            print('selection mode')
            if y1 < 147:
                if 258 < x1 < 450:
                    header = overlay_list[0]
                    drawcolour = (255,0,255)
                elif 550 < x1 < 750:
                    header = overlay_list[1]
                    drawcolour = (255,0,0)
                elif 880 < x1 < 950:
                    header = overlay_list[2]
                    drawcolour = (0,255,0)
                elif 1050 < x1 < 1200:
                    header = overlay_list[3]
                    drawcolour = (0,0,0)
            cv2.rectangle(img,(x1,y1-23),(x2,y2+23),drawcolour,cv2.FILLED)


        # 5) If Drawing mode  - one finger are up
        if fingers[1] and fingers[2]==False:
            cv2.circle(img,(x1,y1),15,(255,0,255),cv2.FILLED)
            print('drawing mode')
            if xp == 0 and yp == 0:
                xp , yp = x1 , y1

            if drawcolour==(0,0,0):
                cv2.line(img, (xp, yp), (x1, y1), drawcolour, eraserThickness)
                cv2.line(imgCanvas, (xp, yp), (x1, y1), drawcolour, eraserThickness)
            else:
                cv2.line(img,(xp,yp),(x1,y1),drawcolour,brushThickness)
                cv2.line(imgCanvas,(xp,yp),(x1,y1),drawcolour,brushThickness)

            xp, yp = x1 , y1

    imgGray = cv2.cvtColor(imgCanvas,cv2.COLOR_BGR2GRAY)
    _ , imgInv = cv2.threshold(imgGray,50,255,cv2.THRESH_BINARY_INV)
    imgInv = cv2.cvtColor(imgInv,cv2.COLOR_GRAY2BGR)
    img = cv2.bitwise_and(img,imgInv)
    img =cv2.bitwise_or(img,imgCanvas)


    #setting header
    img[0:147,0:1280] = header
    img =cv2.addWeighted(img,0.6,imgCanvas,0.4,0)
    cv2.imshow("PAINTER ", img)
    #cv2.imshow("canvas ", imgCanvas)
    #cv2.imshow('bitwise',imgInv)
    cv2.waitKey(1)