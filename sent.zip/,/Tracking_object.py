import cv2
cap =cv2.VideoCapture(0)
#tracker = cv2.TrackerMOSSE_create()
##try another Tracker which cv2 provides [MIL,Boosting,KCF,Mosse,CSRT,goturn,MedianFlow,TLD,sampler]
tracker = cv2.TrackerMIL_create()
success , img = cap.read()
bbox = cv2.selectROI("Tracking",img,False)
tracker.init(img,bbox)
def drawbox(img,bbox):
    x,y,w,h = int(bbox[0]),int(bbox[1]),int(bbox[2]),int(bbox[3])
    cv2.rectangle(img,(x,y),((x+w),(y+h)),(255,0,255),3,cv2.LINE_8)
    cv2.putText(img, "Tracking", (75, 75), cv2.FONT_HERSHEY_DUPLEX, 0.7, (0, 255, 0), 2)
while True:
    timer = cv2.getTickCount()
    success , img = cap.read()
    success , bbox = tracker.update(img)
    #print(type(bbox))
    if success:
        drawbox(img,bbox)
    else:
        cv2.putText(img, "Lost", (75, 75), cv2.FONT_HERSHEY_DUPLEX, 0.7, (0, 0, 255),2)
    fps = cv2.getTickFrequency()/(cv2.getTickCount()-timer)
    cv2.putText(img,str(int(fps)),(75,52),cv2.FONT_HERSHEY_DUPLEX,0.7,(0,0,255),2)
    cv2.imshow("Tracking",img)


    if cv2.waitKey(1) &0xff==ord('q'):
        break



#FACE DETECTION
#
#
#
#
# import cv2
# import numpy as np
# cap = cv2.VideoCapture(0)
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
#
# while True:
#     success ,img =cap.read()
#     face_detect = face_cascade.detectMultiScale(img,scaleFactor=1.1,minNeighbors=5)
#     # print(face_detect)
#     for x,y,w,h in face_detect:
#         cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,200),2,cv2.LINE_AA)
#     cv2.imshow("video", img)
#     if cv2.waitKey(1) & 0xff ==ord('q'):
#         cv2.destroyAllWindows()
#         break