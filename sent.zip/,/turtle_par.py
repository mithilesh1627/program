import turtle
wn = turtle.Screen()    # creates a graphics window
wn.setup(720,720)       # set window dimension

alex = turtle.Turtle()  # create a turtle named alex
alex.shape("turtle")    # alex looks like a turtle
#draws circles
alex.left(180)
c = ["red","green","blue"]
for i in range(0,3):
      alex.color(c[i])
      alex.right(90)
      for counter in range(1,5):
            alex.circle(20*counter)
             
   
