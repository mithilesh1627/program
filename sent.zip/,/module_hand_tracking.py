import cv2
import mediapipe as mp
import time
import math
class HandDetector():
    def __init__(self,mode=False,max_num_hands=2,min_tracking_confidence = 0.5,
                 min_detection_confidence=0.5):
        self.mode=mode
        self.max_num_hands = max_num_hands
        self.min_tracking_confidence = min_tracking_confidence
        self.min_detection_confidence= min_detection_confidence
        self.mphands = mp.solutions.hands
        self.hands = self.mphands.Hands(self.mode,self.max_num_hands,
                                        self.min_detection_confidence,
                                        self.min_tracking_confidence)
        self.mpdraw = mp.solutions.drawing_utils
        self.tip_id = [4,8,12,16,20]
    def FindHands(self,img,draw=True):
        imgRGB = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        self.result= self.hands.process(imgRGB)
        #print(result.multi_hand_landmarks)
        if self.result.multi_hand_landmarks:
            for handsLM in self.result.multi_hand_landmarks:
                if draw:
                    self.mpdraw.draw_landmarks(img,handsLM,self.mphands.HAND_CONNECTIONS)


        return img
    def FindPosition(self,img,handnumber=0,draw=True):
        xList = []
        yList = []
        bbox = []
        self.lm_list = []
        if self.result.multi_hand_landmarks:
            myHand=self.result.multi_hand_landmarks[handnumber]
            for id , lm in enumerate(myHand.landmark):
                 # print(id,lm)
                H,W,C = img.shape
                cx ,cy = int(lm.x*W) , int(lm.y*H)
                xList.append(cx)
                yList.append(cy)
                #print(id,cx,cy)
                self.lm_list.append([id,cx,cy])
                if draw:
                    cv2.circle(img,(cx,cy),5,(255,0,0),cv2.FILLED)
            xmin , xmax = min(xList) , max(xList)
            ymin, ymax = min(yList), max(yList)
            bbox = xmin,ymin, xmax ,ymax

            if draw:
                cv2.rectangle(img,(bbox[0]-20,bbox[1]-20),
                              (bbox[2]+20,bbox[3]+20),(0,255,0),2)
        return self.lm_list , bbox

    def FingerUp(self):
        finger = []
        # Thumb
        if self.lm_list[self.tip_id[0]][1] < self.lm_list[self.tip_id[0] - 1][1]:
            finger.append(1)
        else:
            finger.append(0)

        # finger
        for id in range(1, 5):
            # this is for left hander user
            # if you are right hander than use > instead of < only in below line
            if self.lm_list[self.tip_id[id]][2] < self.lm_list[self.tip_id[id] - 2][2]:
                finger.append(1)
            else:
                finger.append(0)
        return finger
    def FindDistance(self,p1,p2,img,draw=True):
        x1, y1 = self.lm_list[p1][1], self.lm_list[p1][2]
        x2, y2 = self.lm_list[p2][1], self.lm_list[p2][2]
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        if draw:
            cv2.circle(img, (x1, y1), 10, (255, 0, 0), cv2.FILLED)
            cv2.circle(img, (x2, y2), 10, (255, 0, 0), cv2.FILLED)
            cv2.line(img, (x1, y1), (x2, y2), (255, 0, 0), 3, cv2.LINE_AA)
            cv2.circle(img, (cx, cy), 10, (255, 0, 0), cv2.FILLED)

        length = math.hypot(x2 - x1, y2 - y1)
        return length,img ,[x1,y1,x2,y2,cx,cy]
def main():
    ptime = 0
    ctime = 0
    cap = cv2.VideoCapture(0)  # for internal camera
    detector= HandDetector()
    while True:
        success, img = cap.read()
        img= detector.FindHands(img)
        lm_list=detector.FindPosition(img,draw=False)#draw if true
        if len(lm_list)!=0:
            print(lm_list[4])

        ctime = time.time()
        fps = 1 / (ctime - ptime)
        ptime = ctime

        cv2.putText(img, str(int(fps)), (10, 70), cv2.FONT_HERSHEY_DUPLEX, 2
                    , (255, 0, 255), 2)

        cv2.imshow("Image", img)
        cv2.waitKey(1)

if __name__=="__main__":
    main()
