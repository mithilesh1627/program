import cv2
import cvzone
from cvzone.FaceMeshModule import FaceMeshDetector
from cvzone.PlotModule import LivePlot
import mediapipe
# i am going to use Face MeshModule instead of FaceDetectionModule
# because FaceMeshModule has 460 landmark which is less than FaceDetectionModule


cap = cv2.VideoCapture(0) # o for camera or put src of video
detector = FaceMeshDetector(maxFaces=1)
plotY = LivePlot(640,380,[20,50],invert=True)
idList_for_left_eyes = [22, 23, 24, 110, 157, 158, 159, 160, 161, 130, 243]
ratio_list=[]
blink_counter =0
counter = 0
color = (255,0,255)

while True:

    # if want to video running continue then use below line in this i using live camara
    #     so i didn't need this
    # if cap.get(cv2.CAP_PROP_POS_FRAMES)==cap.get(cv2.CAP_PROP_FRAME_COUNT):
    #     cap.set(cv2.CAP_PROP_POS_FRAMES,0)

    success, img = cap.read()
    img ,faces = detector.findFaceMesh(img,draw=False)
    if faces:
        face = faces[0]
        for id in idList_for_left_eyes:
            cv2.circle(img,face[id],5,color,cv2.FILLED)
        leftUp = face[159]
        leftdown = face[23]
        leftLeft = face[130]
        leftRigth = face[243]
        lengthVer = detector.findDistance(leftUp,leftdown)
        lengthHor = detector.findDistance(leftLeft,leftRigth)

        cv2.line(img,leftUp,leftdown,(0,200,0),3)
        cv2.line(img,leftLeft,leftRigth,(0,200,0),3)
        ratio = int((lengthVer[0]/lengthHor[0])*100)
        ratio_list.append(ratio)
        if len(ratio_list)>3:
            ratio_list.pop(0)
        ratioAvg = sum(ratio_list)/len(ratio_list)
        if ratioAvg<=32 and counter==0:
            blink_counter+=1
            color=(0,200,0)
            counter =1
        if counter!=0:
            counter+=1
            if counter>10:
                counter=0
                color=(255,0,255)
        cvzone.putTextRect(img,f"Blink Count: {blink_counter}",(50,100),
                           colorR=color)

        imgPlot = plotY.update(ratioAvg,color=color)
        img = cv2.resize(img,(640,360))
        imgPlot = cv2.resize(imgPlot,(640,360))
        stackimg = cvzone.stackImages([img,imgPlot],2,1)
    else:
        img = cv2.resize(img, (640, 360))
        stackimg = cvzone.stackImages([img, img], 2, 1)#set 1 for Vertical stack
                                                       #set 2 for Horizontal stack

    cv2.imshow("Image",stackimg)
    cv2.waitKey(25)